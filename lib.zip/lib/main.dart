import 'package:flutter/material.dart';
import 'package:flutter_application_1/history/date.dart';
import 'SplashScreen/SplashScreen.dart';
import 'Login/login.dart';
import 'Signup/signup.dart';
import 'Home/home.dart';
import 'Formulir/tambah.dart';
import 'ProsesLaporan/TimelineLaporan.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lapor Pak',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        useMaterial3: true,
      ),

      // 👇 Halaman pertama yang muncul saat app dijalankan
      home: const DatePage(),

      // 👇 Rute navigasi utama
      routes: {
        '/login': (context) => const Login(),
        '/signup': (context) => const SignUp(),
        '/home': (context) => const HomeWarga(),
        '/tambah': (context) => const UploadKeluhan(),
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../flutterViz_bottom_navigationBar_model.dart';

class ProfileKetua extends StatelessWidget {
  final List<FlutterVizBottomNavigationBarModel> navItems = [
    FlutterVizBottomNavigationBarModel(icon: Icons.home, label: "Home"),
    FlutterVizBottomNavigationBarModel(icon: Icons.people, label: "Data Warga"),
    FlutterVizBottomNavigationBarModel(icon: Icons.add, label: "Tambah Laporan"),
    FlutterVizBottomNavigationBarModel(icon: Icons.history, label: "Riwayat"),
    FlutterVizBottomNavigationBarModel(icon: Icons.account_circle, label: "Account"),
  ];

  final int _selectedIndex = 4; // aktif di Akun

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 4,
        centerTitle: true,
        backgroundColor: const Color(0xff5f34e0),
        title: const Text(
          "Lapor Pak - Ketua RT",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            color: Colors.white,
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: navItems
            .map((item) => BottomNavigationBarItem(
                  icon: Icon(item.icon),
                  label: item.label,
                ))
            .toList(),
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xff5f33e2),
        unselectedItemColor: const Color(0xffb5a1f0),
        onTap: (index) {
          // TODO: Navigasi ke halaman sesuai index untuk Ketua RT
        },
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.network("https://assets8.lottiefiles.com/packages/lf20_8ydmsved.json",
                height: 150),
            const SizedBox(height: 10),
            const Text(
              "Profil Ketua RT",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Text("Nama: Pak Sugeng", style: TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                // TODO: Tambahkan logout atau navigasi lain
              },
              icon: const Icon(Icons.logout),
              label: const Text("Keluar Akun"),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xff5f34e0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../flutterViz_bottom_navigationBar_model.dart';
import '../history/datert.dart'; // pastikan path ini benar

// ============================================
// 🔹 Widget Video Autoplay di Header
// ============================================
class VideoHeader extends StatefulWidget {
  const VideoHeader({super.key});

  @override
  State<VideoHeader> createState() => _VideoHeaderState();
}

class _VideoHeaderState extends State<VideoHeader> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/LaporPak.mp4')
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
        _controller.setLooping(true);
        _controller.setVolume(1.0); // volume normal
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Container(
      height: screenWidth < 400 ? 180 : 180,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
      ),
      clipBehavior: Clip.antiAlias,
 child: _controller.value.isInitialized
    ? IgnorePointer(
        ignoring: true,
        child: VideoPlayer(_controller),
      )
    : const Center(
        child: CircularProgressIndicator(color: Color(0xff5f34e0)),
      ),

    );
  }
}

// ============================================
// 🔹 Halaman HomeScreen RT
// ============================================
class HomeScreenrt extends StatefulWidget {
  const HomeScreenrt({super.key});

  @override
  State<HomeScreenrt> createState() => _HomeScreenrtState();
}

class _HomeScreenrtState extends State<HomeScreenrt> {
  int _selectedIndex = 0;

  final List<FlutterVizBottomNavigationBarModel> navItems = [
    FlutterVizBottomNavigationBarModel(icon: Icons.home, label: "Home"),
    FlutterVizBottomNavigationBarModel(icon: Icons.calendar_today, label: "Date"),
    FlutterVizBottomNavigationBarModel(icon: Icons.add, label: "Tambah"),
    FlutterVizBottomNavigationBarModel(icon: Icons.description, label: "History"),
    FlutterVizBottomNavigationBarModel(icon: Icons.account_circle, label: "Account"),
  ];

  final List<Map<String, dynamic>> steps = [
    {
      "icon": Icons.report_problem_outlined,
      "title": "1. Warga Membuat Laporan",
      "desc": "Laporan warga dengan jelas dan lengkap.",
    },
    {
      "icon": Icons.upload_file_outlined,
      "title": "2. Warga Mengunggah Bukti",
      "desc": "Warga menambahkan foto atau video untuk memperkuat laporan.",
    },
    {
      "icon": Icons.verified_outlined,
      "title": "3. RT Akan Memverifikasi",
      "desc": "RT (Anda) akan memverifikasi laporan warga.",
    },
    {
      "icon": Icons.done_all_outlined,
      "title": "4. Selesai",
      "desc": "Pantau hingga laporan Anda tangani dengan baik.",
    },
  ];

  // ============================================
  // 🔹 Navigasi Bottom Bar
  // ============================================
  void _onItemTapped(int index) {
    if (index == _selectedIndex) return; // hindari reload page
    setState(() => _selectedIndex = index);

    switch (index) {
      case 0:
        // Tetap di halaman Home RT
        break;

      case 1:
        // ✅ Navigasi ke halaman Date RT
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const DatePage()),
        );
        break;

      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Menu ${navItems[index].label} belum diaktifkan")),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: const Color(0xfff7f7f7),

      // ==========================
      // Bottom Navigation
      // ==========================
      bottomNavigationBar: BottomNavigationBar(
        items: navItems
            .map(
              (item) => BottomNavigationBarItem(
                icon: Icon(item.icon),
                label: item.label,
              ),
            )
            .toList(),
        backgroundColor: Colors.white,
        currentIndex: _selectedIndex,
        elevation: 8,
        iconSize: 22,
        selectedItemColor: const Color(0xff5f33e2),
        unselectedItemColor: const Color(0xffb5a1f0),
        selectedFontSize: 10,
        unselectedFontSize: 9,
        showSelectedLabels: true,
        showUnselectedLabels: false,
        onTap: _onItemTapped, // ✅ aktifkan tombol navigasi
        type: BottomNavigationBarType.fixed,
      ),

      // ==========================
      // Body Layout
      // ==========================
      body: SingleChildScrollView(
        child: Column(
          children: [
            // ==================================================
            // HEADER AREA
            // ==================================================
            Stack(
              children: [
                Container(
                  height: screenWidth < 400 ? 240 : 260,
                  decoration: const BoxDecoration(
                    color: Color(0xff5f34e0),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(35),
                      bottomRight: Radius.circular(35),
                    ),
                  ),
                ),
                SafeArea(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: const [
                            Icon(Icons.menu, color: Colors.white, size: 26),
                            Text(
                              "Lapor Pak",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Icon(Icons.notifications_none, color: Colors.white, size: 26),
                          ],
                        ),
                      ),
                      const SizedBox(height: 15),
                      const VideoHeader(),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 25),

            // ==================================================
            // CARD "HALO RT"
            // ==================================================
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 25),
              decoration: BoxDecoration(
                color: const Color(0xff5f34e0),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Halo, Pak RT 👋",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Selamat datang di aplikasi Lapor Pak!\nTempat warga melaporkan keluhan lingkungan dengan mudah dan cepat.",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 13,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orangeAccent,
                      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: const Text(
                      "Lihat Laporan",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // ==================================================
            // TUTORIAL 4 LANGKAH
            // ==================================================
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: const [
                      Text(
                        "Langkah Penggunaan",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      Spacer(),
                      Text(
                        "Lihat Semua",
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xff5f34e0),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: steps.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio:
                          screenWidth < 350 ? 0.95 : screenWidth < 400 ? 1.05 : 1.15,
                    ),
                    itemBuilder: (context, index) {
                      final step = steps[index];
                      return Container(
                        decoration: BoxDecoration(
                          color: const Color(0xfff8f6ff),
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(
                            color: const Color(0xffe6e1ff),
                            width: 1,
                          ),
                        ),
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                color: const Color(0xff5f34e0).withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              padding: const EdgeInsets.all(10),
                              child: Icon(
                                step["icon"],
                                color: const Color(0xff5f34e0),
                                size: 28,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              step["title"],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              step["desc"],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 11,
                                color: Colors.black54,
                                height: 1.3,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
